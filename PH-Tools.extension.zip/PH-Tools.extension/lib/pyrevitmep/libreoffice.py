# coding: utf8
import clr
clr.AddReferenceToFileAndPath(r"C:\Program Files\LibreOffice\program\cli_uno.dll")
clr.AddReferenceToFileAndPath(r"C:\Program Files\LibreOffice\program\cli_types.dll")
from unoidl.com.sun.star import uno