# coding: utf8

class System(object):
    def __init__(self):
        pass

class SystemType(object):
    def __init__(self):
        pass


class DuctSystemType(SystemType):
    def __init__(self):
        pass

class PipingSystemType(SystemType):
    def __init__(self):
        pass