"""PyRevitMEP module
These module common tools for pypevitmep
"""

__author__ = 'Cyril Waechter'