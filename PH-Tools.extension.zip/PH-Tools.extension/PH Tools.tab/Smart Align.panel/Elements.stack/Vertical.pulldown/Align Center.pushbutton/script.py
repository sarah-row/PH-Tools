"""
__title__ = 'Align Elements Vertically: Center'

_____________________________________________________________________
Description:

Will Align selected Elements
_____________________________________________________________________
How-to:

-> Select elements to align
-> Click the button
_____________________________________________________________________

"""


import sys
import os
sys.path.append(os.path.dirname(__file__))
from smartalign.align import main
from smartalign.core import Alignment, VERBOSE

ALIGN = Alignment.HCENTER
# ALIGN = Alignment.HLEFT
# ALIGN = Alignment.HRIGHT
# ALIGN = Alignment.VCENTER
# ALIGN = Alignment.VTOP
# ALIGN = Alignment.VBOTTOM

main(ALIGN)
