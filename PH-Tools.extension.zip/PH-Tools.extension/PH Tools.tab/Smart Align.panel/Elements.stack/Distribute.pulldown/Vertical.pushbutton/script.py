"""
__title__ = 'Distribute Elements Vertically'

_____________________________________________________________________
Description:

Will Align selected Elements
_____________________________________________________________________
How-to:

-> Select elements to align
-> Click the button
_____________________________________________________________________

"""

import sys
import os
sys.path.append(os.path.dirname(__file__))
from smartalign.distribute import main
from smartalign.core import Alignment, VERBOSE

# ALIGN = Alignment.HDIST
ALIGN = Alignment.VDIST
main(ALIGN)
