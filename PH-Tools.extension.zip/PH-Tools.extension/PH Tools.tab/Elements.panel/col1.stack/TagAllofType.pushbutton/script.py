# -*- coding: utf-8 -*-
__title__ = "Tag all similar in Active View"
__version__ = 'Version = 1.0'
__doc__ = """
_____________________________________________________________________
Description:
Will tag all elements of the same type as the selected element.
Works well for hangers
_____________________________________________________________________
"""

# ╦╔╦╗╔═╗╔═╗╦═╗╔╦╗╔═╗
# ║║║║╠═╝║ ║╠╦╝ ║ ╚═╗
# ╩╩ ╩╩  ╚═╝╩╚═ ╩ ╚═╝ IMPORTS
# ==================================================


# .NET Imports
import os, clr
import clr
clr.AddReference("RevitAPI")
clr.AddReference("System")
from System.Collections.Generic import List
from pyrevit import revit, DB
from pyrevit import script
from pyrevit import forms

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import *


output = script.get_output()
selection = revit.get_selection()


filered_elements = []
model_items = []
viewspecific_items = {}

# verify selection
if not selection:
    forms.alert('At least one object must be selected.', exitscript=True)

# collect element matching selected input
for selected_element in selection:
    is_viewspecific = selected_element.ViewSpecific

    # find type id
    if isinstance(selected_element, DB.CurveElement):
        type_id = selected_element.LineStyle.Id
    else:
        type_id = selected_element.GetTypeId()

    # determine by class or by category
    by_class = category_id = None
    if isinstance(selected_element, DB.Dimension):
        by_class = DB.Dimension
    else:
        category_id = selected_element.Category.Id

    # collect all target elements
    if by_class:
        same_cat_elements = \
            DB.FilteredElementCollector(revit.doc)\
            .OfClass(by_class)\
            .WhereElementIsNotElementType()\
            .ToElements()
    else:
        same_cat_elements = \
            DB.FilteredElementCollector(revit.doc)\
            .OfCategoryId(category_id)\
            .WhereElementIsNotElementType()\
            .ToElements()

    # find matching types
    for sim_element in same_cat_elements:
        if isinstance(sim_element, DB.CurveElement):
            r_type = sim_element.LineStyle.Id
        else:
            r_type = sim_element.GetTypeId()
        if r_type == type_id:
            filered_elements.append(sim_element.Id)
            if is_viewspecific:
                ovname = \
                    revit.query.get_name(
                        revit.doc.GetElement(sim_element.OwnerViewId)
                        )
                if ovname in viewspecific_items:
                    viewspecific_items[ovname].append(sim_element)
                else:
                    viewspecific_items[ovname] = [sim_element]
            else:
                model_items.append(sim_element)
# select results
revit.get_selection().set_to(filered_elements)

# Tag the elements
t = DB.Transaction(revit.doc, "Tag Elements")
t.Start()

tag_mode = DB.TagMode.TM_ADDBY_CATEGORY
tag_orientation = DB.TagOrientation.Horizontal
view = revit.doc.ActiveView  # Add this line to get the active view

for element_id in filered_elements:
    element = revit.doc.GetElement(element_id)
    reference = DB.Reference(element)

    # Create a tag with the element's location reference
    try:
        tag = DB.IndependentTag.Create(revit.doc, view.Id, reference, True, tag_mode, tag_orientation,
                                       DB.XYZ(0, 0, 0))
    except Exception as e:
        print("Error creating tag:", e)

t.Commit()





