# -*- coding: utf-8 -*-
__title__ = "Export to NWC"
__version__ = "1.0"
__doc__ = """
Will only export views that contain Navis in the view name
The File name will not include Navis in the name

All files are exported to C:NWC_Exports and the folder will be created if it doesn't exist
"""

import clr
clr.AddReference("RevitAPI")
from Autodesk.Revit.DB import *
import os

doc = __revit__.ActiveUIDocument.Document

# Get all views in the document
views_collector = FilteredElementCollector(doc).OfClass(View)

# Filter views that contain "Navis" in the name
view_ids = [view.Id for view in views_collector if "Navis" in view.Name]

from Autodesk.Revit.DB import NavisworksExportOptions

# Create the export options
options = NavisworksExportOptions()

# Create the export folder if it doesn't exist
export_folder = "C:\\NWC_Exports\\"
if not os.path.exists(export_folder):
    os.makedirs(export_folder)

# Export each view as .nwc
for view_id in view_ids:
    view = doc.GetElement(view_id)
    view_name = view.Name
    file_name = "{}.nwc".format(view_name.replace("Navis", ""))
    doc.Export(export_folder, file_name, options)